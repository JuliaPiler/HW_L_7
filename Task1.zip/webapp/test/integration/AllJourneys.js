/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"jetCources/Task1/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"jetCources/Task1/test/integration/pages/Worklist",
	"jetCources/Task1/test/integration/pages/Object",
	"jetCources/Task1/test/integration/pages/NotFound",
	"jetCources/Task1/test/integration/pages/Browser",
	"jetCources/Task1/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "jetCources.Task1.view."
	});

	sap.ui.require([
		"jetCources/Task1/test/integration/WorklistJourney",
		"jetCources/Task1/test/integration/ObjectJourney",
		"jetCources/Task1/test/integration/NavigationJourney",
		"jetCources/Task1/test/integration/NotFoundJourney",
		"jetCources/Task1/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});